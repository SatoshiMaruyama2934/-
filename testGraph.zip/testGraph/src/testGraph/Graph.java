package testGraph;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Graph {
	private int student;
	int[] score;
	int sum;
	int max;
	int min;
	double average;
	boolean flag = false;

	public void inputStudent() {
		
		System.out.print("生徒の人数を入力してください : ");
		while(flag==false) {
			try {
				flag=true;

				Scanner sc = new Scanner(System.in);
				this.student = sc.nextInt();
				while(this.student <= 0) {
					System.err.print("【ERROR】無効な値です。もう一度入力してください\n(半角/1以上の整数):");
					this.student = sc.nextInt();
					
				}
				
			}catch(InputMismatchException e) {
				System.err.print("【ERROR】無効な値です。もう一度入力してください\n(半角/1以上の整数):");
				this.flag=false;
			}
		}
		this.flag=false;
	}

	public void inputScore() {	//点数を入力するだけ
		
		this.score = new int[student];	//生徒数ぶんの要素を持つ配列を作成
		int count = 0;
		this.flag=false;
		Scanner sc = new Scanner(System.in);
		
		for(int i=0;i<score.length;i++) {	//ループ
			try {
				this.flag=true;
				System.out.print("点数を入力してください : ");
				score[i]=sc.nextInt();
				while(score[i]<min||score[i]>max) {
					System.err.printf("【ERROR】無効な値です。もう一度入力してください\n(%d～%dの整数):",this.min,this.max);
					
					score[i]=sc.nextInt();
					this.flag=false;
					count++;
					
				}
			}
			catch(InputMismatchException e) {
				System.err.println("【ERROR】無効な値です。もう一度入力してください\n");
				System.err.printf("(%d～%dの整数を入力):",this.min,this.max);
				i=count-1;
				sc.nextLine();
			}

		}
	}

	public void calcSum() { // 合計

		for (int i : score) { // score配列の中身を取り出していく
			this.sum += i; // 順番に足していく
		}

	}

	public void calcAvg() { // 平均
		this.average = (double) sum / student; // 計算
	}

	public void outputResult() { // 出力
		System.out.println("-----------------------------------");
		System.out.print("結果を出力します...");
		System.out.println("");
		System.out.print("----"); // 左端

		for (int i = 0; i < student; i++) {
			System.out.print("------"); // 枠線を人数に合わせて伸ばす
		}
		System.out.println("----"); // 右端

		for (int i = 0; i < max / 10; i++) { // 上の行から10点ずつ評価
			System.out.printf("%3d", (max - (i * 10)));// maxは点数の最大値
			System.out.print("|"); // 得点の目盛を数字で出力した後、グラフの枠を出力

			for (int j = 0; j < student; j++) { // 「*」の数はグラフの長さ=点数
				if (max - (i * 10) <= score[j]) { // グラフの頂点=その人の得点
					System.out.print("  *  |"); // その上には何もない=空白であるはず
				} else { // グラフの頂点(=[j]さんの得点)より上の位置には
					System.out.print("     |"); // グラフの空白部分を出力
				}
			}
			System.out.print(max - (i * 10)); // 得点の目盛を数字で出力
			System.out.println(""); // 改行して、次の行を評価
		}
		// グラフ直下の行
		System.out.print("---|"); // 最初の仕切り線
		for (int i : score) {
			System.out.print("-----|"); // score配列の要素の数＝生徒数のぶん、枠線と仕切り線を出力
		}
		System.out.print("---"); // 右端
		System.out.println(""); // 改行して次の結果を出力

		// 各生徒の点数を出力する行
		System.out.print("   |"); // 次の行のはじめの仕切り線

		for (int i : score) { // score配列の要素を取り出す
			System.out.printf("[%3d]", i); // 各生徒の点数を出力
			System.out.print("|"); // 仕切り線
		}
		System.out.println(""); // 改行
		System.out.print("-----"); // 左端

		for (int i = 0; i < student; i++) {
			System.out.print("------"); // 枠線を人数に合わせて伸ばす
		}

		System.out.print("-----"); // 右端
		System.out.println(""); // 改行
		System.out.print("   |");
		for (int i = 0; i < student; i++) {
			String result = "不可";
			if (score[i] >= 80) {
				result = " 優 ";
			} else if (score[i] >= 70) {
				result = " 良 ";
			} else if (score[i] >= 60) {
				result = " 可 ";
			}

			System.out.printf(" %s|", result);
		}

		System.out.println(""); // 改行
		System.out.printf("合計点 : %3d点\n", sum); // 合計点の出力
		System.out.printf("平均点 : %.1f点 ", average); // 平均点の出力
	}

	Graph() {
		this.sum = 0;
		this.max = 100;
		this.min = 0;
	}

}

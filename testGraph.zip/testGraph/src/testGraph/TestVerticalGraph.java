/**
 *入力された「STUDENT」名のテストの点数を「0～100」の範囲内で入力し、
 *その合計点と平均点を算出、グラフと共に出力
 *1目盛りを10点として「*」を描画し、縦軸のグラフに出力する
 *また、各生徒の得点に応じて、4段階の評定を与える
 *90～100...
 */

package testGraph;

public class TestVerticalGraph {

	public static void main(String[] args) {
		
		Graph g = new Graph();
		g.inputStudent();	//生徒数の入力
		g.inputScore();		//入力 メソッド側で配列を初期化
		g.calcSum();		//合計
		g.calcAvg();		//平均
		g.outputResult();	//出力

	}
	

	

	




}
